package com.example.outfitsync

import androidx.compose.ui.graphics.Color

val Pink = Color(0xFFEB9CA1)
val Beige = Color(0xFFF6EFEA)
val DarkText = Color(0xFF222222)
val Accent = Color(0xFFB86F74)
