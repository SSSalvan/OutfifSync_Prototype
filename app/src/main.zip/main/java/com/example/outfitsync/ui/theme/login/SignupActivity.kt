package com.example.outfitsync.ui.theme.login

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.dashboard_outfitsync.R

class SignupActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.fragment_signup)

        // Anda bisa menambahkan logika untuk tombol back, sign in, dan sign up di sini
    }
}